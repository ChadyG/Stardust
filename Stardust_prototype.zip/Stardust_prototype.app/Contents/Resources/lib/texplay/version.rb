module TexPlay
    VERSION = "0.2.981"
end
