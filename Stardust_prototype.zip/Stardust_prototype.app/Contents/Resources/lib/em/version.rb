module EventMachine
  VERSION = "0.12.10"
end
