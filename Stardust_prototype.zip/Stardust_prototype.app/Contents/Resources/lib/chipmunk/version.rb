module Chipmunk
  VERSION = "5.2.2"
end
